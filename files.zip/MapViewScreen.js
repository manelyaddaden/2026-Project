import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  SafeAreaView,
  ScrollView,
} from 'react-native';

export default function MapViewScreen({ navigation, route }) {
  const { items = [] } = route.params || {};

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backIcon}>←</Text>
          <Text style={styles.backText}>Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Map View</Text>
      </View>

      {/* Map Placeholder */}
      <View style={styles.mapPlaceholder}>
        <Text style={styles.mapIcon}>🗺️</Text>
        <Text style={styles.mapTitle}>Map View Coming Soon!</Text>
        <Text style={styles.mapText}>
          This feature will show items on an interactive map based on their location.
        </Text>
        <Text style={styles.mapText}>
          You'll be able to see which items are closest to you!
        </Text>
      </View>

      {/* Items List Below */}
      <View style={styles.itemsSection}>
        <Text style={styles.itemsSectionTitle}>
          {items.length} item{items.length !== 1 ? 's' : ''} nearby
        </Text>
        <ScrollView showsVerticalScrollIndicator={false}>
          {items.map((item) => (
            <TouchableOpacity
              key={item.id}
              style={styles.itemCard}
              onPress={() => navigation.navigate('ItemDetail', { item })}
            >
              <View style={styles.itemIcon}>
                <Text style={styles.itemIconText}>📦</Text>
              </View>
              <View style={styles.itemInfo}>
                <Text style={styles.itemTitle}>{item.title}</Text>
                <Text style={styles.itemLocation}>{item.location}</Text>
              </View>
              <Text style={styles.itemPrice}>${item.pricePerDay}/day</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: '#5B51D8',
    paddingTop: 20,
    paddingBottom: 20,
    paddingHorizontal: 20,
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
  },
  backButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  backIcon: {
    fontSize: 24,
    color: '#fff',
    fontWeight: 'bold',
    marginRight: 8,
  },
  backText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
  },
  mapPlaceholder: {
    backgroundColor: '#E8E4F3',
    margin: 20,
    padding: 40,
    borderRadius: 16,
    alignItems: 'center',
  },
  mapIcon: {
    fontSize: 64,
    marginBottom: 16,
  },
  mapTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#5B51D8',
    marginBottom: 12,
  },
  mapText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 8,
  },
  itemsSection: {
    flex: 1,
    paddingHorizontal: 20,
  },
  itemsSectionTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  itemCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
  },
  itemIcon: {
    width: 50,
    height: 50,
    backgroundColor: '#E8E4F3',
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  itemIconText: {
    fontSize: 24,
  },
  itemInfo: {
    flex: 1,
  },
  itemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  itemLocation: {
    fontSize: 12,
    color: '#999',
  },
  itemPrice: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#5B51D8',
  },
});
