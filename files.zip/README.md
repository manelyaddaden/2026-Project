# NeighborLend MVP - Real App! 🚀

This is your REAL MVP for the competition - no more examples!

## What's Built

### ✅ Working Features:
1. **Home Screen** - Grid of items from Firebase
2. **Item Detail Page** - Full item info
3. **Create Ad** - 2-step form with photo upload
4. **Search & Filters** - Search by name + filter by category
5. **Map View** - Placeholder (ready for real map later)
6. **Firebase Integration** - Real database storage

### 📱 Screens:
- **HomeScreen.js** - Browse items, search, filter
- **ItemDetailScreen.js** - View full item details
- **CreateAdScreen.js** - Multi-step form to add items
- **MapViewScreen.js** - Map view (placeholder for now)

## 🔥 FIREBASE SETUP - FOLLOW THESE STEPS!

### Step 1: Create Firebase Project
1. Go to https://console.firebase.google.com
2. Click "Add project"
3. Name it "NeighborLend" (or whatever you want)
4. Disable Google Analytics (not needed for MVP)
5. Click "Create project"

### Step 2: Set Up Firestore Database
1. In Firebase Console, click "Firestore Database" in left menu
2. Click "Create database"
3. Choose "Start in test mode" (we'll add security later)
4. Choose a location close to you
5. Click "Enable"

### Step 3: Set Up Firebase Storage (for images)
1. In Firebase Console, click "Storage" in left menu
2. Click "Get started"
3. Choose "Start in test mode"
4. Click "Done"

### Step 4: Get Your Firebase Config
1. In Firebase Console, click the gear icon ⚙️ > "Project settings"
2. Scroll down to "Your apps"
3. Click the web icon `</>`
4. Name your app "NeighborLend Web"
5. Click "Register app"
6. **COPY the firebaseConfig object** - it looks like this:

```javascript
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc123"
};
```

### Step 5: Add Config to Your App
1. Open `firebaseConfig.js` in your project
2. **REPLACE** the placeholder values with YOUR config from Firebase
3. Save the file

### Step 6: Update Firestore Rules (Important!)
1. In Firebase Console, go to Firestore Database
2. Click "Rules" tab
3. Replace the rules with this (allows everyone to read/write for now):

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

4. Click "Publish"

### Step 7: Update Storage Rules
1. In Firebase Console, go to Storage
2. Click "Rules" tab
3. Replace with:

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if true;
    }
  }
}
```

4. Click "Publish"

**⚠️ IMPORTANT:** These rules allow anyone to read/write. Fine for MVP and testing, but we'll add authentication and proper rules later!

## 💻 HOW TO RUN YOUR APP

### First Time Setup:
```bash
npm install
npx expo start
```

### Test on Phone:
1. Download "Expo Go" app
2. Scan the QR code
3. App loads on your phone!

### Test in Browser:
- Press `w` after running `npx expo start`

## 🎯 HOW TO TEST ALL FEATURES

### 1. Create Your First Item:
1. Click "+ Create an ad"
2. Fill in title (e.g., "Power Drill")
3. Select category (e.g., "Tools")
4. Enter price (e.g., "5")
5. Upload a photo (from gallery or camera)
6. Enter availability (e.g., "Available weekdays")
7. Click "Next Step"
8. Enter description
9. Enter location (e.g., "Montreal, QC")
10. Enter your name
11. Click "Create Ad"
12. ✅ Item appears on home screen!

### 2. Search & Filter:
1. Type in search bar
2. Click category filters
3. Items update automatically

### 3. View Item Details:
1. Click any item card
2. See full details
3. Click "Contact Owner" (shows coming soon message)

### 4. Map View:
1. Click "🗺️ Map" button
2. See placeholder (real map coming later)

## 📁 PROJECT STRUCTURE

```
NeighborLendApp/
├── App.js                      # Navigation setup
├── firebaseConfig.js           # Firebase setup (ADD YOUR CONFIG!)
├── package.json                # Dependencies
├── app.json                    # Expo config
└── screens/
    ├── HomeScreen.js           # Main screen with item grid
    ├── ItemDetailScreen.js     # Item details
    ├── CreateAdScreen.js       # Create new items
    └── MapViewScreen.js        # Map view (placeholder)
```

## 🎨 DESIGN

**Colors:**
- Main Purple: `#5B51D8`
- Background: `#fff` (white)
- Text: `#333` (dark gray)
- Light Purple: `#E8E4F3`

**Clean & Modern:**
- Rounded corners (12-30px)
- Soft shadows
- Purple curved headers
- Grid layout for items

## 🔧 HOW IT WORKS

### Firebase Firestore Structure:
```
items/ (collection)
  └── item1 (document)
      ├── title: "Power Drill"
      ├── category: "Tools"
      ├── description: "..."
      ├── pricePerDay: 5
      ├── availability: "..."
      ├── location: "Montreal, QC"
      ├── ownerName: "Emma"
      ├── imageUrl: "https://..."
      └── createdAt: timestamp
```

### Photo Upload Flow:
1. User picks/takes photo
2. Image uploaded to Firebase Storage
3. Get download URL
4. Save URL in Firestore with item data

## 📝 WHAT'S NEXT (After MVP Works)

**Week 3-4:**
- Add real map with markers
- Location-based search

**Week 5-6:**
- User authentication (login/signup)
- User profiles

**Week 7-8:**
- Chat/messaging between users
- Booking system

**Week 9-10:**
- Polish, testing, bug fixes
- Prepare presentation

## 🐛 TROUBLESHOOTING

**"Firebase not configured"**
- Make sure you replaced the config in `firebaseConfig.js`

**"Permission denied"**
- Check Firestore and Storage rules (Step 6 & 7)

**"Can't upload image"**
- Make sure you allowed camera/photo permissions

**"Items not showing"**
- Create an item first!
- Check Firebase Console > Firestore Database to see if data is there

**"Network error"**
- Make sure your phone/computer has internet
- Firebase requires internet connection

## 🎉 YOU'RE READY!

Your MVP is ready to test! Try creating a few items and show it to your mentor.

**Next Steps:**
1. Set up Firebase (follow steps above)
2. Run the app
3. Create some test items
4. Show your mentor
5. Ask me for next features!

Good luck! 🚀
